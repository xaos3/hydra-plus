This folder has the precompiled third party libraries for the ubuntu linux,
and a compilation script for compiling [Hydra+] to
the target system. 