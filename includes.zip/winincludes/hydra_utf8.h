/*
 Support for utf8 strings operations

 Nikolaos Mourgis deus-ex.gr 2024

 Live Long and Prosper
*/


char *hdr_return_utf8_pos(PDX_STRING str , DXLONG64 from_indx, DXLONG64 *byte_pos )
{
    /*
      returns the utf8 char of the string (first byte position) and the binary_pos will be set to the first byte position in the string
    */

    if((from_indx > (str->len-1))||(from_indx < 0)) return NULL ;
    char *prev_char = NULL ;
    int char_len ;
    *byte_pos = 0 ;
    char *utf8 = str->stringa ;
    for(DXLONG64 i = 0 ; i<from_indx ; i++ )
    {
      dx_get_utf8_char_ex2(&utf8,&prev_char,&char_len) ;
      *byte_pos = *byte_pos + char_len ;
    }

  return utf8;
}

DXLONG64 hdr_Utf8CharPos(PDX_STRING source , DXUTF8CHAR c , DXLONG64 fr_indx)
{
    /*
     The function return the absolute position of the [c] in characters. For example in the string 12345 
     the character 4 is in the 3 position.
     The function starts the search from the fr_indx that is too in characters and not bytes.
    */
     if(source == NULL) return -1 ;
     if(source->len == 0) return -1 ;
     if(c == 0) return -1   ;

     DXUTF8CHAR cc1      ;
     char *utf8_1 , *utf8tmp ;
     int charlen ;
     /*get to the position*/
     utf8_1 = dx_string_return_utf8_pos(source,fr_indx) ;
     if(utf8_1 == NULL) return -1 ;
     
     DXLONG64 chpos = 0   ;
     while(true)
     {
         cc1 =dx_get_utf8_char_ex2(&utf8_1,&utf8tmp,&charlen) ;
         if (cc1 == 0) return -1     ; // end of the source string, the char was not found

         if(cc1 == c) return chpos ;

         chpos++ ;

    }

  return -1 ;
}


PDX_STRING hdr_Utf8CopyUntilChar(PDX_STRING source , DXUTF8CHAR c , DXLONG64 *fr_indx)
{
    /*
	 The function starts from the fr_index and copy the string until the [c]. If the [c] does not exists 
	 then all the string from fr_indx until the end is copied and the fr_indx will set to -1.
	 When the function return the $fr_indx will have the position of the 
	 next character after the [c] OR if the character is the last of the string , the fr_indx will
	 have the position of the [c]
     In error the function return an empty PDX_STRING
	*/
     if((*fr_indx < 0)||(*fr_indx > (source->len-1))) 
     {
         *fr_indx = -1 ;
         return dx_string_createU(NULL,"") ;
     }
    char *utf8tmp = NULL ;
    char *utf8_1  = NULL ;
    DXLONG64 start_indx  ;
    /*go to the position*/
    if(*fr_indx > 0 )
    {
       utf8_1  = hdr_return_utf8_pos(source,*fr_indx,&start_indx) ;
    }
    else
    {
        utf8_1 = source->stringa ;
        start_indx = 0 ;
    }

    if(utf8_1 == NULL) 
    {
        *fr_indx = -1 ;
        /*binary copy all the string*/
        start_indx = 0 ;
        return CopyIndxToIndx(source,start_indx,source->bcount-1) ;
    }

    /*parse all the string to find the positions for copyng*/
    DXUTF8CHAR cc1 = 0 ;
    int char_len   = 0 ;
    DXLONG64 byte_len = 0 ; 
    while(true)
    {
        cc1 = dx_get_utf8_char_ex2(&utf8_1,&utf8tmp,&char_len) ;
        if((cc1 == c)||(cc1==0)) 
        {
          break ;
        }
       
        byte_len  = byte_len + char_len ;
        (*fr_indx)++ ; 
    }

    if (byte_len == 0)
    {
        /*the character was not found OR found but its the first character of the search so nothing will be copy*/
        if(cc1 != c) *fr_indx = -1 ;
        return dx_string_createU(NULL,"") ;
    }

    if(*fr_indx == source->len)
    {
      /*the *fr_indx has count the terminating 0 too that means that the character was not found*/
      *fr_indx = -1 ;
      return CopyIndxToIndx(source,start_indx,source->bcount-1) ; 
    }

    /*now copy the string*/
    return CopyIndxToIndx(source,start_indx,start_indx+(byte_len-1)) ;

}






















